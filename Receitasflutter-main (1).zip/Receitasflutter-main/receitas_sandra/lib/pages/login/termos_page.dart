import 'package:flutter/material.dart';

class TermosPage extends StatelessWidget {
  static const routeName = '/TermosPage';
  const TermosPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text('Termos e condições'),
    );
  }
}
