import 'package:flutter/material.dart';

class EntrarFonePage extends StatefulWidget {
  const EntrarFonePage({Key? key}) : super(key: key);

  @override
  _EntrarFonePageState createState() => _EntrarFonePageState();
}

class _EntrarFonePageState extends State<EntrarFonePage> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.grey,
    );
  }
}
